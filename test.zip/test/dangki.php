
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style2.css">

<title>Kinh doanh dong ho xach tay</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
			<a href="index.html"><img src="img/MOD-17-479_Maddaloni_Web_Banner_1800x450-1680x450.jpg" ></a>
			</div>
			<ul class="main_menu">
			  <li>
					<a href="#">Thương Hiệu</a>
					<ul class="TH">
						<li>
							<a href="#">Movado</a>
						</li>
						<li>
						<a href="#">Daniel Wellington</a>
						</li>
						<li><a href="Casio.php">Casio</a></li>
					</ul>
				</li>
			    <li><a href="#">Tin Tức</a></li>
			    <li><a href="#">Liên Hệ - Hỏi Đáp</a>
			    <ul class="TH">
			    	<li><a href="hoidap.html">Thắc Mắc - Góp Ý</a></li>
			    	<li><a href="thongtinlienhe.html">Thông Tin Liên Hệ</a></li>
			    </ul>
			    </li>
                <li><a href="login.php">Đăng nhập</a></li>
                <li><a href="giohang.php">Giỏ hàng</a></li>
			</ul>
				<form class="search">
				<input type="text" name="s" placeholder="Tìm Kiếm" >
				</form>
		</div>
	</div>
	<div class="clearfix">
		<div class="NoiDung">
			<div class="TrangChu_container" >
				<div class="noidungdk"><a>Đăng kí</a></div>
				<div class="dangki"><form action="" method="post" enctype="multipart/form-data">
					<ul>
						<li>Tên Khách hàng <input type="text" name="hotenkh"></li>
						<li>Địa chỉ <input type="text" name="diachi"></li>
						<li>Số điện thoại <input type="text" name="sdt"</li>
						<li>Tên đăng nhập <input type="text" name="user"</li>
						<li>Mật khẩu <input type="password" name="password"</li>
						
						<li><input type="submit" name="submit" value="Đăng Ký" /></li>
					</ul></form>
					<?php	
							if(isset($_POST['submit'])){
							print_r($_POST);
							$con = mysqli_connect("localhost","root","","donghoxachtay");
							$idGroup = 2;
							$hotenkh = $_POST["hotenkh"];
							$diachi = $_POST["diachi"];
							$sdt = $_POST["sdt"];
							$user = $_POST["user"];
							$password = $_POST["password"];
							$sql = "INSERT INTO TaiKhoan(idgroup, hotenkh, diachi, sdt, user, password) VALUES('$idGroup','$hotenkh','$diachi','$sdt','$user','$password') ";
							mysqli_query($con,$sql);
							header("location:dangki.php");
							}
					?>
				</div>
				
			</div>
		</div>
	</div>
	</div>
		</div>
	<div class="End">
		<div class="TrangChu_container">
			<div class="thongtin">
				<p>Shop ban dong ho xach tay</p>
				<p>Dia Chi : xxx </p>
				<p>SDT : 01226480545</p>
			</div>
		</div>
	</div>
</div>
</body>
</html>
