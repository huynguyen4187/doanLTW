<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>QuanTri</title>
</head>
	
<body>
</body>
</html>
<?php
$conn = mysqli_connect('localhost','root','','WebDongHo')or die('Khong the ket noi');
$sql ='SELECT * FROM TaiKhoan';
$result= mysqli_query($conn,$sql);
if(!$result){
	die('Cau truy van bi sai');
}
while($row = mysqli_fetch_assoc($result))
{
	var_dump($row);
}
?>
<form action="QuanTri.php" method="POST">
	Username :<input type="text" 	name="user"/><br>
	Password :<input type="password" name="pass"/><br>
	<input type="submit" value="Dang nhap" name="submit"/>
</form>