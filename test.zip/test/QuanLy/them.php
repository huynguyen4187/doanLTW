<!doctype html>
<?php 
	session_start();
	require("../lib/dbCon.php"); ?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="../css/style3.css">
<title>Quản lý sản phẩm</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
				<img src="../img/MOVADO.png" width="840px" height="250px">
			</div>
		</div>
	</div>
		<div class="clearfix">
	<div class="NoiDung">
		<div class="TrangChu_container">
				<div class="TrangQuanLy">
					<ul>
						<li><a>Thêm sản phẩm</a></li>
					</ul>
				</div>
				<div class="themsp"><form action="" method="post" enctype="multipart/form-data">
					<ul>
						
						<li>Tên đồng hồ: <input type="text" name="tendongho" /></li>
						<li>Giá: <input type="text" name="gia" /></li>
						<li>Chi Tiết: <input type="text" name="chitiet" /></li>
						<li>Hãng: <select name="idhang">
						<?php 
							$idhang = "SELECT * FROM hang";
							$data = mysqli_query($con, $idhang);
							while($row= mysqli_fetch_assoc($data)){
						?>
							<option value="<?php echo $row['idhang'] ?>"><?php echo $row['tenhang'] ?></option>
						<?php } ?>
						</select></li>
						<li>Số Lượng: <input type="text" name="soluong" /></li>
						<li>Hình Ảnh: <input  type="file" name="image" id="image" value="Chọn hình" /></li>
						<li><input type="submit" name="submit" value="Thêm" /></li>
					</ul></form>
					<?php
						if(isset($_POST['submit'])){
							print_r($_POST);
							if($_FILES['image']['name'] != NULL){ // Đã chọn file
							   // Tiến hành code upload file
							   if($_FILES['image']['type'] == "image/jpeg"
								|| $_FILES['image']['type'] == "image/png"
								|| $_FILES['image']['type'] == "image/gif"){
								  // là file ảnh
								  // Tiến hành code upload
								  if($_FILES['image']['size'] > 2048576){
									  echo "File không được lớn hơn 2mb";
								  }else{
									  // file hợp lệ, tiến hành upload
									  $path = "../images/"; // ảnh upload sẽ được lưu vào thư mục image
									  $tmp_name = $_FILES['image']['tmp_name'];
									  $name = $_FILES['image']['name'];
									  $type = $_FILES['image']['type']; 
									  $size = $_FILES['image']['size']; 
									  // Upload file
									  move_uploaded_file($tmp_name,$path.$name);
									  
								  }
								}else{
								  // không phải file ảnh
								  echo "Kiểu file không hợp lệ";
								}
						  }
						  else{
							   echo "Vui lòng chọn file";
						  }
							$idhang = $_POST["idhang"];
							$tendongho = $_POST["tendongho"];
							$gia = $_POST["gia"];
							$chitiet = $_POST["chitiet"];
							
							$soluong = $_POST["soluong"];
							
							
							
							
							$sql = "INSERT INTO sanpham  VALUES(NULL,'$tendongho','$gia','$chitiet','$idhang','$soluong','$name') ";
							//print_r($sql);
							mysqli_query($con,$sql);
							header("location:quanlysanpham.php");
						}
					?>
				</div>
		</div>
	</div>
		</div>
</div>
</body>
</html>
