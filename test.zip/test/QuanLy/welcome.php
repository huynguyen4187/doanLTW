<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style2.css">
<title>Quan ly</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
				<img src="img/MOVADO.png" width="840px" height="250px">
			</div>
		</div>
	</div>
		<div class="clearfix">
	<div class="NoiDung">
		<div class="TrangChu_container">
				<div class="TrangQuanLy">
					<ul>
						<li><a>Trang Quản Lý</a></li>
					</ul>
				</div>
				<div class="quantri">
					<ul>
						<li><a>Quản lý sản phẩm</a></li>
						<li><a>Quản lý đơn hàng</a></li>
					</ul>
				</div>
		</div>
	</div>
		</div>
</div>
</body>
</html>
