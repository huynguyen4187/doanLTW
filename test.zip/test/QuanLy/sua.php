<!doctype html>
<?php 
	session_start();
	require("../lib/dbCon.php"); 
	$id = $_GET['id'];	
?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="../css/style3.css">
<title>Quản lý sản phẩm</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
				<img src="../img/MOVADO.png" width="840px" height="250px">
			</div>
		</div>
	</div>
		<div class="clearfix">
	<div class="NoiDung">
		<div class="TrangChu_container">
				<div class="TrangQuanLy">
					<ul>
						<li><a>Them San Pham</a></li>
					</ul>
				</div>
				<div class="menuqlsp"><form action="" method="post" enctype="multipart/form-data">
					<ul>
						<?php
                        	$sanpham ="SELECT * FROM sanpham WHERE idsp = ".$_GET['id']."";
							$result = mysqli_query($con, $sanpham);
							$datasp = mysqli_fetch_assoc($result);
							//print_r($datasp);
						?>
						<li>Tên đồng hồ: <input type="text" name="tendongho" value="<?php echo $datasp['tensp'] ?>"/></li>
						<li>Giá: <input type="text" name="gia" value="<?php echo $datasp['giasp'] ?>" /></li>
						<li>Chi Tiết: <input type="text" name="chitiet" value="<?php echo $datasp['chitietsp'] ?>" /></li>
						<li>Hang: 
                            <select name="idhang">
                            <?php 
                                $idhang = "SELECT * FROM hang";
                                $data = mysqli_query($con, $idhang);
                                while($row= mysqli_fetch_assoc($data)){
                            ?>
                                <option value="<?php echo $row['idhang'] ?>"><?php echo $row['tenhang'] ?></option>
                            <?php } ?>
                            </select>
                        </li>
                        
						<li>Số Lượng: <input type="text" name="soluong" value="<?php echo $datasp['soluongSP'] ?>"/></li>
						
						<li><input type="submit" name="submit" value="UPDATE" /></li>
					</ul></form>
                    <?php
						if (isset($_POST["submit"])) {
							//print_r($_POST);
							/*$path = "upload/"; // ảnh upload sẽ được lưu vào thư mục data
						 	$tmp_name = $_FILES["hinhNH"]["tmp_name"];
							$name = $_FILES["hinhNH"]["name"];*/
							$nhanHieu = $_POST["idhang"];
							$tensp = $_POST["tendongho"];
							$giasp = $_POST["gia"];
							$soluong = $_POST["soluong"];
							$chitiet = $_POST["chitiet"];
							
							/*move_uploaded_file($tmp_name,$path.$name);*/
							$sql = "UPDATE sanpham SET
							tensp = '$tensp',
							giasp = '$giasp',
							chitietsp = '$chitiet',
							idhang = '$nhanHieu',
							soluongSP = '$soluong' 
							
							WHERE idsp = '$id'" ;
							mysqli_query($con,$sql);
							echo "<pre>";
							print_r($sql);
							header("location:quanlysanpham.php");
						}
						
					?>
				</div>
		</div>
	</div>
		</div>
</div>
</body>
</html>
