<!doctype html>
<?php 
	require("../lib/dbCon.php");
	session_start(); 
	if(!isset($_SESSION['user'])){
		header("location:../index.html");
	}

?>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="../css/style3.css">
<title>Quản lý sản phẩm</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
				<img src="../img/MOVADO.png" width="840px" height="250px">
			</div>
		</div>
	</div>
		<div class="clearfix">
	<div class="NoiDung">
		<div class="TrangChu_container">
				<div class="TrangQuanLy">
					<ul>
						<li><a>Quản lý sản phẩm</a></li>
					</ul>
					<form action="timkiem.php" method="get">
                	Search: <input type="text" name="search" />
                	<input type="submit" name="ok" value="Tìm kiếm " />
            		</form>
				</div>
				<div class="menuqlsp"><form action="" method="">
					<table id="table">
						<tr>
							<td>Mã SP</td>
							<td>Tên SP</td>
							<td>Hang</td>
							<td>Giá SP</td>
							<td>Chi Tiết</td>
							<td>Số lượng</td>
							<td><a href="them.php">Thêm</a></td>
							
						</tr>
                        <?php
							$query="SELECT * FROM sanpham";
							$data = mysqli_query($con,$query);
							//print_r($data);
							while($sanpham = mysqli_fetch_assoc($data)){
						?>
						<tr>
						
							<td><?php echo $sanpham['idsp'] ?></td>
							<td><?php echo $sanpham['tensp'] ?></td>
							<td><?php echo $sanpham['idhang']?></td>
							<td><?php echo $sanpham['giasp'] ?></td>
							<td><?php echo $sanpham['chitietsp'] ?></td>
							<td><?php echo $sanpham['soluongSP'] ?></td>
							<td><a href="xoa.php?id=<?php echo $sanpham['idsp'] ?>">Xoá</a>&nbsp;&nbsp;&nbsp;<a href="sua.php?id=<?php echo $sanpham['idsp'] ?>">Sữa</a>&nbsp;&nbsp;&nbsp;</td>
							
						</tr>
                        <?php } ?>
					</table></form>
				</div>
			<div class="dangxuat"><a href="dangxuat.php">Đăng xuất</a></div>
		</div>
	</div>
		</div>
</div>
   
</body>
</html>
