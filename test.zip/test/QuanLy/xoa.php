
<?php
	require('../lib/dbCon.php');
	$id = $_GET['id'];
	$qr = "DELETE FROM sanpham WHERE idsp = '$id'";
	mysqli_query($con,$qr);
	header("location:quanlysanpham.php");
?>