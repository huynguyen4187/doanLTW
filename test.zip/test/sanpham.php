<?php
	require "lib/dbCon.php";
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width-device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style2.css">
<title>Thong tin san pham</title>
</head>

<body>
<div class="TrangChu">
	<div class="Menu">
		<div class="TrangChu_container">
			<div class="logo">
			<a href="index.html"><img src="img/MOD-17-479_Maddaloni_Web_Banner_1800x450-1680x450.jpg" width="900px" height="300px"></a>
			</div>
		  <ul class="main_menu">
			  <li>
					<a href="#">Thương Hiệu</a>
					<ul class="TH">
						<li>
							<a href="sanpham.php?id=1">Movado</a>
						</li>
						<li>
						<a href="sanpham.php?id=2">Daniel Wellington</a>
						</li>
						<li><a href="sanpham.php?id=3">Casio</a>
                        </li>
					</ul>
			</li>
			    <li><a href="#">Tin Tức</a></li>
			    <li><a href="hoidap.html">Liên Hệ - Hỏi Đáp</a>
			    <ul class="TH">
			    	<li><a href="hoidap.html">Thắc Mắc - Góp Ý</a></li>
			    	<li><a href="thongtinlienhe.html">Thông Tin Liên Hệ</a></li>
			    </ul>
			    </li>
                <li><a href="login.php">Đăng nhập</a></li>
                <li><a href="dangki.php">Đăng kí</a></li>
                <li><a href="#">Giỏ Hàng</a></li>
			</ul>
				<form class="search">
				<input type="text" name="s" placeholder="Tìm Kiếm" >
				</form>
		</div>
	</div>
	<div class="clearfix">
		<div class="NoiDung">
			<div class="TrangChu_container">
				<div class="info4"> 
                <h1 align="center" style="color:#0FF">Thông tin sản phẩm</h1>
                	<ul>
                    <?php
                    	$sql="SELECT * FROM sanpham WHERE idhang = ".$_GET['id']."";
						//print_r($_GET['id']);
						$data =  mysqli_query($con,$sql);
						
						//print_r($data);
						while($row =  mysqli_fetch_assoc($data)){
							//print_r($row['tensp']);
					?>
                    
                    	
                        <li><img src="img/<?php echo $row['hinhanh'] ?>" width="150px;" height="200px;">
                        <p style="color:#00C"><?php echo $row['tensp'] ?></p>
                        <p style="color:#F00;">Giá : <?php echo $row['giasp'] ?></p>
                        <p style="color:#F00; text-align:center; font-size: 15px;"><a href="#"><input type="button" value="Đặt hàng"</a></p>
 						</li>
                    
                     <?php 
						}
					 ?>  
                      </ul> 
				</div>
			</div>
		</div>
	</div>
	<div class="End">
		<div class="TrangChu_container">
			<div class="thongtin">
				Nhom D14_TH03
			</div>
		</div>
	</div>
</div>
</body>
</html>
