<?php
	$svname ="localhost";
	$username = "root";
	$pass = "";
	$dbname = "donghoxachtay";
	$con = mysqli_connect($svname,$username,$pass,$dbname);
	mysqli_set_charset($con,"utf8");
?>