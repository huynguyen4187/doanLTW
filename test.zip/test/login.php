<?php 
	require "lib/dbCon.php"; 
	session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>
<style>
.login{
width:360px;
margin:50px auto;
font:Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
border-radius:10px;
border:2px solid #ccc;
padding:10px 40px 25px;
margin-top:70px;	
}
input[type=text], input[type=password]{
width:99%;
padding:10px;
margin-top:8px;
border:1px solid #ccc;
padding-left:5px;
font-size:16px;
font-family:Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;	
}
input[type=submit]{
width:100%;
background-color:#009;
color:#fff;
border:2px solid #06F;
padding:10px;
font-size:20px;
cursor:pointer;
border-radius:5px;
margin-bottom:15px;	
}
</style>
</head>
<body>
<div class="login">
<h1 align="center">Login</h1>
<form action="" method="post" style="text-align:center;">
    <input type="text" placeholder="Username" id="user" name="user"><br/><br/>
    <input type="password" placeholder="Password" id="password" name="password"><br/><br/>
    <input type="submit" value="Login" name="submit">
</form>
<!-- Error Message -->
<?php 
	if(isset($_POST['submit'])){
		$username = $_POST["user"];
		$password = $_POST["password"];
		if ($username == "" || $password =="") {
			echo '<span style="color:red">Vui lòng điền đầy đủ thông tin!</span>';
		}else{
			//ktra user vs pass
			$sql = "SELECT * FROM taikhoan WHERE user = '$username' AND password = '$password'";
			$query = mysqli_query($con,$sql);
			$num_rows = mysqli_num_rows($query);
			//ktra admin
			$idG = "SELECT * FROM taikhoan WHERE user = '$username' AND password = '$password' AND idgroup = 1";
			$qr = mysqli_query($con, $idG);	
			$num_qr=mysqli_num_rows($qr);
			//print_r($num_qr);
			if ($num_rows==0) {
				echo '<span style="color:red">Tên đăng nhập hoặc mật khẩu không đúng !</span>';
			}
			else if($num_rows > 0 && $num_qr > 0){
				$_SESSION['user'] = $username;
				echo "Xin chào <b>".$username."</b>. Bạn đã đăng nhập thành công. <b><a href='QuanLy/quanlysanpham.php'>Đến trang quản lý</a></b>";
				die();
			}
			else{
				$_SESSION['user'] = $username;
				echo "Xin chào <b>".$username."</b>. Bạn đã đăng nhập thành công.<b><a href='index.html'> Đến trang chủ </a></b>";
			}
		}
	}
?>
<span></span>
</body>
</html>